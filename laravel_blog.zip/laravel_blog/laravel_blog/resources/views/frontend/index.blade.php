@extends('layouts.app')

@section('content')
    good
@endsection