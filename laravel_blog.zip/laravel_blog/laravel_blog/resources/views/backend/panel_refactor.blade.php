@extends('layouts.backend')


@section('content')
    <div style="margin-bottom: 20px; margin-top: 30px;" class="col-md-12">


        <span style="font-size: 20px; "><b>Категории</b></span>

        <div style="float: right">
            <a class="btn btn-primary" href="{{ url('/backend/edit_category') }}" >
                <i class="material-icons m-block">add</i>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#id</th>
                            <th>Титулка</th>
                            <th>Короткий опис</th>
                            <th>Опис</th>
                            <th>Дата публікації</th>
                            <th>Опублікований</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dvos as $dvo)
                            <tr>
                                <th scope="row">{{ $dvo->getId() }}</th>
                                <td>{{ $dvo->getTitle() }}</td>
                                <td>{{ $dvo->getShortDesc() }}</td>
                                <td>{{ $dvo->getDesc() }}</td>
                                <td>{{ $dvo->getPublishedAt() }}</td>
                                <td><a href="{{ url('/backend/published_enable/'.$dvo->getId()) }}" id="enable_product" style="width: 24px; height: 24px;" class="btn {{ $dvo->isEnableCategory() ? 'btn-success'  : 'btn-danger' }}"></a>
                                </td>
                                <td><div class="pull-right">
                                        <a class="btn btn-info" href="{{ url('/backend/edit_category', ['id_category' => $dvo->getId()]) }}"><i class="material-icons m-block">edit</i></a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
@endsection