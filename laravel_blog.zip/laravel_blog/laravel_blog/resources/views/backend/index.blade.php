@extends('layouts.backend')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="list_categories" style="text-align: center">
                <h2>Категорії</h2>
            </div>
        </div>
    </div>
</div>
@endsection
