<?php
/**
 * Created by PhpStorm.
 * User: sumsung
 * Date: 16.01.17
 * Time: 15:02
 */

namespace App\Mappers\Backend;


use App\Dvo\Backend\CategoryDvo;

class CategoryMapper
{

    public function mapList($categories){
        $categoriesDvo = array();
        foreach ($categories as $category){
            $categoriesDvo[] = new CategoryDvo($category);
        }
        return $categoriesDvo;
    }

    public function mapForId($category){
        return new CategoryDvo($category);
    }
}