<?php
/**
 * Created by PhpStorm.
 * User: sumsung
 * Date: 16.01.17
 * Time: 14:57
 */

namespace App\Dvo\Backend;


class CategoryDvo
{
    public $categories;

    /**
     * CategoryDvo constructor.
     * @param $categories
     */
    public function __construct($categories)
    {
        $this->categories = $categories;
    }

    public function getId(){
        return $this->categories->id_category;
    }

    public function getTitle(){
        return $this->categories->title_category;
    }

    public function getShortDesc(){
        return $this->categories->short_desc;
    }

    public function getDesc(){
        return $this->categories->desc_category;
    }

    public function isEnableCategory(){
        return $this->categories->published !== '' && $this->categories->published == 1 ? true : false;
    }

    public function getPublishedAt(){
        return $this->categories->published_at;
    }

}