<?php
/**
 * Created by PhpStorm.
 * User: sumsung
 * Date: 16.01.17
 * Time: 14:15
 */

namespace App\Http\Controllers\Backend;


use App\Http\Controllers\Controller;
use App\Mappers\Backend\CategoryMapper;
use App\Models\Category;
use App\Repositories\CategoryRepositories;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{
    private $categoryRepository;
    private $categoryMapper;

    /**
     * CategoriesController constructor.
     * @param $categoryRepository
     */
    public function __construct(
        CategoryRepositories $categoryRepository,
        CategoryMapper $categoryMapper,
        Request $request
    )
    {
        $this->categoryRepository = $categoryRepository;
        $this->categoryMapper = $categoryMapper;
        $this->request = $request;
    }


    public function showPanelRefactor(){
        $categories = $this->categoryRepository->getCategory();
        $dvos = $this->categoryMapper->mapList($categories);
        return view('backend.panel_refactor', ['dvos' => $dvos]);
    }

    public function editCategory($categoryId = 0){
        //Форма добавлення статті
        if($categoryId == 0 && $this->request->isMethod('GET')){
            return view('backend.create_category',['categoryId' => $categoryId]);
        }
        //Форма редагування статті
        if($categoryId != 0 && $this->request->isMethod('GET')){
            $all_category_id = $this->categoryRepository->getCategoryId($categoryId);
            return view('backend.create_category',[
                'categoryId' => $categoryId,
                'dvos' => $this->categoryMapper->mapForId($all_category_id)]
            );

        }
    }

    public function createCategory($categoryId){
        if($this->request->has('action_delete')){
            $this->categoryRepository->deleteCategory($categoryId);
        }
        elseif ($this->request->has('action_save')){
            if($this->request->has('title_category') && $this->request->has('desc_category')){
                $category = $categoryId == 0 ? new Category() : $this->categoryRepository->getCategoryId($categoryId);
                $category->title_category = $this->request->get('title_category', '');
                $category->short_desc = $this->request->get('short_desc', '');
                $category->desc_category = $this->request->get('desc_category', '');
                $category->published_at = $this->request->get('published_at', '');
                $category->published = $this->request->get('published', 'off') == 'on' ? 1 : 0;
                $category->save();
            }else{
                return redirect('/backend/edit_category/'.$categoryId);//todo доробити передачу даних
            }
        }
        return redirect('/backend/panel_refactor');
    }

    public function enablePublished($id_category){
        $category = $this->categoryRepository->getCategoryId($id_category);
        if($category->published == 0){
            $category->published = 1;
        }else{
            $category->published = 0;
        }
        $category->save();
        return redirect('/backend/panel_refactor');
    }
}