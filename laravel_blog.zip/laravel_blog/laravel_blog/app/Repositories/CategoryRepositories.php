<?php
/**
 * Created by PhpStorm.
 * User: sumsung
 * Date: 16.01.17
 * Time: 14:08
 */

namespace App\Repositories;


use App\Models\Category;

class CategoryRepositories
{
    public function getCategory(){
        $categories = Category::latest('published_at')->get();

        return $categories;
    }

    public function getValuesForm($request){
        return $request->all();
    }

    public function getCategoryId($category_id){
        return Category::where('id_category', $category_id)->first();
    }

    public function deleteCategory($category_id){
        return Category::where('id_category',$category_id)->delete();
    }
}