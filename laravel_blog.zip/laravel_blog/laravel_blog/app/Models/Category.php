<?php
/**
 * Created by PhpStorm.
 * User: sumsung
 * Date: 16.01.17
 * Time: 14:08
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'categories';
    protected $primaryKey = 'id_category';

}