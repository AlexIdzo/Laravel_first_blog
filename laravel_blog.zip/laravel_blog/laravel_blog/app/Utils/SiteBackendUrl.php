<?php
/**
 * Created by PhpStorm.
 * User: sumsung
 * Date: 16.01.17
 * Time: 13:22
 */

namespace App\Utils;


class SiteBackendUrl
{
    public static function backendUrl(){
        return url("/");
    }
}