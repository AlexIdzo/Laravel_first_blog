<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();


/**Backend*/
//Auth
Route::get('/backend', ['as' => 'backend.login', 'uses' => 'Auth\LoginController@showLoginForm']);

//dashboard
Route::get('/backend/home',['as' => 'home', 'uses' => 'Backend\HomeBackendController@index']);

//categories
Route::get('/backend/panel_refactor', ['as' => 'panel.refactor', 'uses' => 'Backend\CategoriesController@showPanelRefactor']);
Route::get('/backend/edit_category', ['as' => 'category.add', 'uses' => 'Backend\CategoriesController@editCategory']);
Route::get('/backend/edit_category/{id_category}', ['as' => 'category.refactor', 'uses' => 'Backend\CategoriesController@editCategory']);
Route::post('/backend/action_category/{id_category}', ['as' => 'post.category.add', 'uses' => 'Backend\CategoriesController@createCategory']);
Route::get('/backend/published_enable/{id_category}', ['as' => 'category.enable', 'uses' => 'Backend\CategoriesController@enablePublished']);

//Frontend
Route::get('/',['as' => 'index','uses' => 'Frontend\HomeController@index']);


