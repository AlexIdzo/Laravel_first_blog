<?php $__env->startSection('content'); ?>
    <div style="margin-bottom: 20px; margin-top: 30px;" class="col-md-12">


        <span style="font-size: 20px; "><b>Категории</b></span>

        <div style="float: right">
            <a class="btn btn-primary" href="<?php echo e(url('/backend/edit_category')); ?>" >
                <i class="material-icons m-block">add</i>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#id</th>
                            <th>Титулка</th>
                            <th>Короткий опис</th>
                            <th>Опис</th>
                            <th>Дата публікації</th>
                            <th>Опублікований</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dvos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dvo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($dvo->getId()); ?></th>
                                <td><?php echo e($dvo->getTitle()); ?></td>
                                <td><?php echo e($dvo->getShortDesc()); ?></td>
                                <td><?php echo e($dvo->getDesc()); ?></td>
                                <td><?php echo e($dvo->getPublishedAt()); ?></td>
                                <td><a href="<?php echo e(url('/backend/published_enable/'.$dvo->getId())); ?>" id="enable_product" style="width: 24px; height: 24px;" class="btn <?php echo e($dvo->isEnableCategory() ? 'btn-success'  : 'btn-danger'); ?>"></a>
                                </td>
                                <td><div class="pull-right">
                                        <a class="btn btn-info" href="<?php echo e(url('/backend/edit_category', ['id_category' => $dvo->getId()])); ?>"><i class="material-icons m-block">edit</i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>