<?php $__env->startSection('content'); ?>
    <div class="row">
        <div style="margin-top: 50px">
            <form action="<?php echo e(url('/backend/action_category/'.$categoryId)); ?>" method="post" class="category_form">
                <?php echo csrf_field(); ?>


                <div style="margin-bottom: 20px;">
                    <?php if($categoryId != 0): ?>
                        <span style="font-size: 20px;"><b>Редактирование категории</b></span>
                    <?php else: ?>
                        <span style="font-size: 20px;"><b>Создание категории</b></span>
                    <?php endif; ?>
                    <div style="float: right">
                        <a class="btn btn-default" role="button" href=" <?php echo e(url('/backend/panel_refactor')); ?>"> Отмена</a>
                        <?php if($categoryId != 0): ?>
                            <input type="submit" class="btn btn-danger" value="Удалить" name="action_delete">
                        <?php endif; ?>
                            <input type="submit" class="btn btn-primary" value="Сохранить" name="action_save">
                    </div>
                </div>

                <div class="form-group">
                    <label for="titleCategory">Титул категорії</label>
                    <input type="text" value="<?php echo e($categoryId != 0 ? $dvos->getTitle() : ""); ?>" name="title_category" id="titleCategory" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="shortDesc">Короткий опис</label>
                    <textarea  name="short_desc" id="shortDesc" class="form-control" style="resize: none;"><?php echo e($categoryId != 0 ? $dvos->getShortDesc() : ""); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="DescCategory">Опис</label>
                    <textarea name="desc_category" id="DescCategory" class="form-control" style="resize: none"><?php echo e($categoryId != 0 ? $dvos->getDesc() : ""); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="publishedAt">Дата Публікації</label>
                    <input type="datetime" value="<?php echo e(date('Y-m-d h:i:s')); ?>" name="published_at" id="publishedAt" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="published">Опублікувати: </label>
                    <input type="checkbox" <?php echo e($categoryId != 0 && $dvos->isEnableCategory() ?  "checked='checked'" : ''); ?> name="published" id="published" class="form-control">
                </div>
                
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>